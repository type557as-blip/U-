(function(){
 'use strict';
 if(globalThis.UPlusAPI)return;
 const hosts=new Set(['https://www.eduplus.net','https://eduplus.net']);
 const validId=value=>typeof value==='string'&&/^[a-f0-9]{32}$/i.test(value);
 function courses(data){
  if(!Array.isArray(data))throw new Error('课程接口格式已变化，未将未知数据当作空列表');
  const ids=new Set();
  return data.map(item=>{
   if(!validId(item.id)||typeof item.name!=='string'||ids.has(item.id))throw new Error('课程接口编号缺失或重复');
   ids.add(item.id);return {id:item.id,name:item.name};
  });
 }
 function homeworks(data,courseId){
  if(!validId(courseId)||!Array.isArray(data))throw new Error('作业接口格式已变化，未将未知数据当作空列表');
  return data.map(item=>{
   if(!validId(item.id)||item.courseId!==courseId||!item.homeworkDTO)throw new Error('作业接口课程或发布编号不一致');
   const dto=item.homeworkDTO;
   // submitTask describes the publication, not this student's completion status.
   const subStatus=typeof dto.subStatus==='number'&&Number.isInteger(dto.subStatus)?dto.subStatus:null;
   return {id:item.id,courseId,name:typeof dto.name==='string'?dto.name:'未命名作业',subStatus,
    endTime:typeof item.endTime==='number'&&Number.isFinite(item.endTime)&&item.endTime>0?item.endTime:null,
    delaySubmit:item.delaySubmit===1?1:0,delaySubmitExtendedTime:Number.isFinite(item.delaySubmitExtendedTime)?item.delaySubmitExtendedTime:0};
  });
 }
 function select(items,origin,course,now=Date.now()){
  if(!hosts.has(origin)||!validId(course.id))throw new Error('不支持的 U+ 来源或课程');
  if(!Array.isArray(items))throw new Error('作业接口格式已变化');
  const cards=[],seen=new Set();let expired=0,completed=0,unknown=0;
  for(const item of items){
   if(item.courseId!==course.id||!validId(item.id))throw new Error('作业课程编号不一致');
   if(seen.has(item.id))continue;seen.add(item.id);
   if(![0,1,2,3].includes(item.subStatus)){unknown++;continue}
   if(item.subStatus!==0){completed++;continue}
   if(item.endTime==null){unknown++;continue}
   if(now>item.endTime){expired++;continue}
   const url=new URL('/course/workAnswer/'+course.id+'/'+item.id+'/true',origin);
   url.search=new URLSearchParams({isPiYue:'noPiYue',delayTime:String(item.delaySubmitExtendedTime),endTime:String(item.endTime),delaySubmit:String(item.delaySubmit)}).toString();
   cards.push({url:url.href,title:item.name,courseTitle:course.name,courseId:course.id,publishId:item.id,deadlineKnown:true,deadlineAt:item.endTime,fromAPI:true});
  }
  return {cards,expired,completed,unknown};
 }
 class Client{
  constructor(origin,fetcher){if(!hosts.has(origin))throw new Error('只能在 U+ 同站页面查询');this.origin=origin;this.fetcher=fetcher||globalThis.fetch.bind(globalThis);this.token=null;this.authAt=0;this.controller=null;this.stopped=false}
  stop(){this.stopped=true;this.controller?.abort()}
  async raw(path,token){
   if(this.stopped)throw new Error('用户停止接口查询');
   if(path!=='/api/base/session/token'&&path!=='/api/course/athena/courses/study?types=Theory%2CTrain'&&!/^\/api\/course\/homeworks\/published\/student\?courseId=[a-f0-9]{32}$/i.test(path))throw new Error('接口不在只读查询白名单');
   const controller=new AbortController();this.controller=controller;const timer=setTimeout(()=>controller.abort(),18000);
   try{
    const response=await this.fetcher(this.origin+path,{method:'GET',credentials:'same-origin',redirect:'error',headers:{Accept:'application/json',...(token?{'X-Access-Token':token}:{})},signal:controller.signal});
    if(!response.ok)throw new Error('U+ 接口 HTTP '+response.status+([401,403].includes(response.status)?'，请重新登录':'，请检查网络后重试'));
    let json;try{json=await response.json()}catch(_){throw new Error('U+ 返回非 JSON 内容，请检查登录或网络')}
    if(json?.success!==true)throw new Error('U+ 未确认只读查询成功，请检查登录和课程权限');
    return json.data;
   }catch(error){if(controller.signal.aborted)throw new Error(this.stopped?'用户停止接口查询':'U+ 接口请求超时');throw error}
   finally{clearTimeout(timer);if(this.controller===controller)this.controller=null}
  }
  async auth(){
   if(this.token&&Date.now()-this.authAt<240000)return;
   const data=await this.raw('/api/base/session/token');
   const token=data?.identity?.token?.accessToken;
   if(typeof token!=='string'||!token)throw new Error('U+ 登录会话不可用，请先在同一浏览器登录');
   this.token=token;this.authAt=Date.now();
  }
  async listCourses(){await this.auth();return courses(await this.raw('/api/course/athena/courses/study?types=Theory%2CTrain',this.token))}
  async listHomeworks(id){if(!validId(id))throw new Error('课程编号无效');await this.auth();return homeworks(await this.raw('/api/course/homeworks/published/student?courseId='+id,this.token),id)}
 }
 globalThis.UPlusAPI={Client,courses,homeworks,select,validId};
})();
