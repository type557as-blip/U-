'use strict';
const $=id=>document.getElementById(id);
const DEEPSEEK={endpoint:'https://api.deepseek.com/chat/completions',model:'deepseek-flash'};
let latest=null;
async function send(message){const result=await chrome.runtime.sendMessage(message);if(result?.error)throw new Error(result.error);return result}
async function action(button,fn){
 button.disabled=true;$('message').textContent='';
 try{const result=await fn();if(typeof result==='string')$('message').textContent=result;await refresh()}
 catch(error){$('message').textContent=error.message}
 finally{button.disabled=false}
}
function node(tag,text,parent){const n=document.createElement(tag);if(text)n.textContent=text;if(parent)parent.appendChild(n);return n}
function selected(){return latest?latest.jobs.filter(j=>j.selected):[]}
function render(s){
 latest=s;$('run-state').textContent=s.scanning?'正在查询课程作业接口':s.running?'自动处理中':'等待操作 / 复核';
 $('log').textContent=s.log.join('\n');
 const root=$('jobs'),openIds=new Set(Array.from(root.querySelectorAll('details[open]')).map(d=>d.dataset.id));
 root.replaceChildren();
 if(!s.jobs.length){node('p','暂时没有任务。先扫描课程，或导入作业网址。',root).className='empty';return}
 for(const job of s.jobs){
  const box=node('article','',root);box.className='job';
  const top=node('div','',box);top.className='job-top';
  const check=node('input','',top);check.type='checkbox';check.checked=job.selected;
  check.onchange=()=>send({type:'SELECT',id:job.id,selected:check.checked}).then(refresh).catch(e=>$('message').textContent=e.message);
  node('strong',job.summary?.name||job.title,top);
  node('span',job.status,top).className='status';
  if(job.url){const a=node('a','打开作业',top);a.href=job.url;a.target='_blank';a.rel='noopener'}
  const summary=job.summary;
  if(job.courseTitle)node('p','课程：'+job.courseTitle,box).className='meta';
  if(Number.isFinite(job.deadlineAt))node('p','截止：'+new Date(job.deadlineAt).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai'}),box).className='meta';
  const verified=summary?.rows.filter(r=>r.verified).length||0,total=summary?.rows.length||0;
  node('p',total?'已核对 '+verified+'/'+total+' 题；AI建议 '+summary.rows.filter(r=>r.ai).length+' 题':job.error||job.text||'等待读取题目',box).className='meta';
  if(summary){
   const details=node('details','',box);details.dataset.id=job.id;details.open=openIds.has(job.id);
   node('summary','展开逐题答案与处理结果',details);
   const list=node('div','',details);list.className='results';
   for(const row of summary.rows){
    const card=node('div','',list);card.className='result-row';
    const label={blank:'填空题',text:'文字简答',attachment:'附件题'}[row.type];
    node('strong','第'+row.number+'题'+(label?' · '+label:'')+' · '+row.status+(row.ai?' · AI建议':''),card);
    node('p',row.title,card).className='title';
    node('div','拟填/已存答案：'+(row.displayAnswer||row.answer||'未给出'),card).className='answer';
    if(row.reason)node('div',row.reason,card).className='reason';
   }
  }
 }
}
async function refresh(){render(await send({type:'STATE'}))}
async function scanJobs(autoStart){
 $('message').textContent=autoStart?'正在通过接口查询有效作业，发现后直接自动填写…':'正在仅查询接口，不打开课程列表、不填写作业…';
 const r=await send({type:'SCAN',fromWorkbench:true,autoStart,keepExisting:$('keep').checked,useAI:$('use-ai').checked});
 const partial=r.errors.length>0||r.remaining>0||r.stopped;
 let message='接口查询：发现 '+r.courses+' 门课程；成功检查 '+r.succeeded+' 门，失败 '+(r.attempted-r.succeeded)+' 门，未检查 '+r.remaining+' 门。'+
  '有效未做 '+r.found+' 份，加入 '+r.count+' 个新任务；跳过已提交 '+(r.completed||0)+' 份、已过期 '+r.expired+' 份、状态或截止时间不明 '+r.unknown+' 份。';
 if(!autoStart)message+='本次仅扫描，没有填写或提交作业。';
 else if(r.started)message+='已启动 '+r.started+' 份作业的填写，正式提交仍需确认。';
 else message+='尚未启动自动填写。';
 if(partial)message+='扫描未完整完成，不能据此判断全部课程都没有未做作业。'+r.errors.join('；');
 else if(!r.found)message+='本次已检查的课程中没有符合条件的未完成作业。';
 return message;
}
$('scan').onclick=()=>action($('scan'),()=>scanJobs(true));
$('scan-only').onclick=()=>action($('scan-only'),()=>scanJobs(false));
$('import').onclick=()=>action($('import'),async()=>{const urls=$('urls').value.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);if(!urls.length)throw new Error('请先粘贴网址');const r=await send({type:'IMPORT',urls});return '加入 '+r.count+' 个新任务'});
$('start').onclick=()=>action($('start'),async()=>{if(!selected().some(j=>['待处理','失败','部分待处理','待上传附件','未做（附件题）','需重新核对'].includes(j.status)))throw new Error('没有选中的待处理任务');await send({type:'START',keepExisting:$('keep').checked,useAI:$('use-ai').checked});return '已开始自动填写/重新核对；附件题跳过并标记未做，正式提交仍由你确认'});
$('stop').onclick=()=>action($('stop'),()=>send({type:'STOP'}));
$('select-all').onclick=()=>action($('select-all'),async()=>{for(const j of latest.jobs)await send({type:'SELECT',id:j.id,selected:j.status!=='已提交'})});
$('remove').onclick=()=>action($('remove'),async()=>{const jobs=selected();if(!jobs.length)throw new Error('未选中记录');if(confirm('只移除助手中的 '+jobs.length+' 条记录，不删除 U+ 作业？'))await send({type:'REMOVE',ids:jobs.map(j=>j.id)})});
$('submit').onclick=()=>action($('submit'),async()=>{
 const jobs=selected().filter(j=>j.status!=='已提交');
 if(!jobs.length)throw new Error('请先选中待提交作业');
 if(jobs.some(j=>!j.summary?.rows.length||!j.summary.rows.every(r=>r.verified)))throw new Error('选中的作业仍有未核对题目，请先处理');
 const aiCount=jobs.reduce((sum,j)=>sum+j.summary.rows.filter(r=>r.ai).length,0);
 if(aiCount&&!$('review-ai').checked)throw new Error('请逐题复核 AI 答案，并勾选复核声明');
 if(!confirm('确认提交以下 '+jobs.length+' 份作业？\n'+jobs.map(j=>j.summary.name||j.title).join('\n')+'\n提交前会再次回读核对。'))return;
 const r=await send({type:'SUBMIT',ids:jobs.map(j=>j.id),reviewAI:$('review-ai').checked});return '提交成功：'+r.submitted.join('、');
});
$('export').onclick=()=>{
 if(!latest)return;
 const blob=new Blob([JSON.stringify({exportedAt:new Date().toISOString(),jobs:latest.jobs,scan:latest.lastScan,log:latest.log},null,2)],{type:'application/json'});
 const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='U+逐题处理与复核结果.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
};
$('save-ai').onclick=()=>action($('save-ai'),async()=>{
 const endpoint=$('endpoint').value.trim(),model=$('model').value.trim(),key=$('api-key').value;
 if(!endpoint||!model||!key)throw new Error('请填写接口地址、模型名称和密钥');
 const url=new URL(endpoint);
 if(url.protocol!=='https:'&&!(['127.0.0.1','localhost'].includes(url.hostname)&&url.protocol==='http:'))throw new Error('接口须使用 HTTPS 或本机地址');
 const granted=await chrome.permissions.request({origins:[url.origin+'/*']});if(!granted)throw new Error('未授权模型接口');
 await send({type:'SAVE_AI',endpoint,model,key});$('api-key').value='';$('ai-message').textContent='已设置：'+url.origin+'；密钥仅存本次浏览器会话';return '模型设置已保存。勾选“无参考答案时使用AI”后才会调用。';
});
$('deepseek-preset').onclick=()=>{$('endpoint').value=DEEPSEEK.endpoint;$('model').value=DEEPSEEK.model;$('ai-message').textContent='已选择 DeepSeek 官方接口；请填写你自己的 Key 后授权保存';};
$('test-ai').onclick=()=>action($('test-ai'),async()=>{
 $('ai-message').textContent='正在发送一条简短的连接测试…';
 try{const r=await send({type:'TEST_AI'});$('ai-message').textContent=r.message;return 'AI 接口测试通过。'}
 catch(error){$('ai-message').textContent=error.message;throw error}
});
$('endpoint').value=DEEPSEEK.endpoint;$('model').value=DEEPSEEK.model;
chrome.storage.local.get('ai-settings').then(data=>{const ai=data['ai-settings'];if(ai){$('endpoint').value=ai.endpoint;$('model').value=ai.model}else{$('ai-details').open=true}});
refresh().catch(e=>$('message').textContent=e.message);
setInterval(()=>refresh().catch(()=>{}),1800);
