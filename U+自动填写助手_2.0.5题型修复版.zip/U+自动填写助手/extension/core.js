(function () {
  'use strict';
  if (globalThis.UPlusEngine?.version==='2.0.5') return;
  const origins = new Set(['https://www.eduplus.net', 'https://eduplus.net']);
  const allowedTypes = /简答|问答|论述/;
  function plain(value) {
    const template = document.createElement('template');
    template.innerHTML = String(value == null ? '' : value);
    template.content.querySelectorAll('script,style').forEach(n => n.remove());
    return (template.content.textContent || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
  }
  function parse(value) {
    const input = String(value || '').trim();
    if (/^[a-f0-9]{32}$/i.test(input)) return {pid: input.toLowerCase(), url: null};
    let url;
    try { url = new URL(input, location.origin); } catch (_) { return null; }
    if (!origins.has(url.origin)) return null;
    const match = url.pathname.match(/^\/course\/workAnswer\/([a-f0-9]{32})\/([a-f0-9]{32})(?:\/|$)/i);
    return match ? {pid: match[2].toLowerCase(), courseId: match[1], url: url.href} : null;
  }
  function type(q) {
    if(Number(q.attachmentType)===1)return 'attachment';
    if(q.attachmentType!=null&&Number(q.attachmentType)!==0)return 'unsupported';
    if(Number(q.qsnType)===6)return 'blank';
    if(Number(q.qsnType)===7)return 'text';
    if (Number(q.qsnType) === 3 || /判断/.test(q.qsnName || '')) return 'judge';
    if (Number(q.qsnType) === 1 || /单选/.test(q.qsnName || '')) return 'single';
    if (Number(q.qsnType) === 2 || /多选/.test(q.qsnName || '')) return 'multiple';
    if(q.qsnType==null&&/填空/.test(q.qsnName||''))return 'blank';
    if(q.qsnType==null&&allowedTypes.test(q.qsnName || '')) return 'text';
    return 'unsupported';
  }
  function filled(value) { return value !== null && value !== undefined && String(value).trim() !== ''; }
  function textLines(value){
    const t=document.createElement('template');t.innerHTML=String(value??'');
    t.content.querySelectorAll('script,style').forEach(n=>n.remove());
    t.content.querySelectorAll('br').forEach(n=>n.replaceWith(document.createTextNode('\n')));
    t.content.querySelectorAll('p,div,li').forEach(n=>n.appendChild(document.createTextNode('\n')));
    return (t.content.textContent||'').replace(/\u00a0/g,' ').replace(/\r/g,'').split('\n').map(x=>x.trimEnd()).join('\n').trim();
  }
  function placeholder(value){return /^(?:略|答案略|参考答案略|答案省略|详见附件|见附件|见解析|详见解析|暂无参考答案|无参考答案)[。.!！\s]*$/i.test(plain(value))}
  function toHTML(value){return '<p>'+String(value).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\r\n?/g,'\n').replace(/\n/g,'<br>')+'</p>'}
  function blankCount(q){const n=Number(q.tiankongCount);if(!Number.isInteger(n)||n<1||n>100)throw new Error('未取得有效填空数量，需人工核对');return n}
  function usable(value,q){
    const kind=type(q);
    if(!filled(value)||kind==='unsupported'||kind==='attachment')return false;
    if(kind==='text')return !!textLines(value)&&!placeholder(value);
    if(kind==='blank'){
      try{const parts=String(value).split('@@@');return parts.length===blankCount(q)&&parts.every(p=>textLines(p)&&!placeholder(p))}catch(_){return false}
    }
    return true;
  }
  function attachmentInfo(detail){
    const file=detail?.attachmentStu;
    return file&&typeof file.id==='string'&&file.id.trim()&&typeof file.filePath==='string'&&file.filePath.trim()&&typeof file.originFileName==='string'&&file.originFileName.trim()?{id:file.id,name:file.originFileName}:null;
  }
  function enrich(q,detail){
    const next={...q};for(const key of ['qsnType','qsnName','attachmentType','tiankongCount','isAutojudge','titleText'])if(detail[key]!=null)next[key]=detail[key];return next;
  }
  function saved(data) {
    if (!data || typeof data !== 'object') return {known: false};
    for (const key of ['userAnswer', 'studentAnswer']) {
      if (Object.prototype.hasOwnProperty.call(data, key)) return {known: true, value: data[key]};
    }
    for (const key of ['answerDTO', 'homeworkAnswerDTO', 'hwAnswerDTO', 'hwAnswer', 'homeworkAnswer']) {
      if (data[key] && Object.prototype.hasOwnProperty.call(data[key], 'userAnswer')) return {known: true, value: data[key].userAnswer};
    }
    return {known: false};
  }
  function optionId(o) { return String(o.id == null ? '' : o.id); }
  function splitAnswer(raw, options) {
    if (Array.isArray(raw)) return raw.map(String);
    const text = String(raw).trim();
    if (text.startsWith('[')) {
      try { const list = JSON.parse(text); if (Array.isArray(list)) return list.map(String); } catch (_) {}
    }
    if (options.some(o => optionId(o) === text)) return [text];
    if (/^[A-Za-z]+$/.test(text) && Array.from(text).every(x => options.some(o => optionId(o) === x))) return Array.from(text);
    if (/[,，、;；|\s]/.test(text)) return text.split(/[,，、;；|\s]+/).filter(Boolean);
    return [text];
  }
  function judgement(raw) {
    const text = String(raw).trim().toLowerCase();
    if (['true', '正确', '对', '1'].includes(text)) return 'true';
    if (['false', '错误', '错', '0'].includes(text)) return 'false';
    throw new Error('无法确认判断题答案编码');
  }
  function translate(q, detail, raw, fromAI) {
    const kind = type(q);
    if(kind==='attachment')throw new Error('附件题不能通过文本答案保存，请先上传实际文件');
    if (!filled(raw)) throw new Error('没有可用答案');
    if (kind === 'judge') return judgement(raw);
    if (kind === 'text') {
      if (typeof raw !== 'string' || !raw.trim()) throw new Error('简答答案必须是文本');
      if(placeholder(raw))throw new Error('参考答案是占位内容，不能视为作答');
      const value=fromAI?raw.trim():textLines(raw);
      if(!value)throw new Error('简答答案内容为空');
      return toHTML(value);
    }
    if(kind==='blank'){
      const count=blankCount(q);
      const parts=Array.isArray(raw)?raw:String(raw).split('@@@');
      if(parts.length!==count)throw new Error('填空答案数量与 '+count+' 个空不一致');
      return parts.map(part=>{
        if(typeof part!=='string')throw new Error('每个填空答案必须是文本');
        let value=fromAI?part.trim():textLines(part);
        if(!fromAI&&Number(q.isAutojudge)===1)value=value.split('\n').map(x=>x.trim()).find(Boolean)||'';
        if(!value||placeholder(value)||value.includes('@@@'))throw new Error('存在空白、占位或编码不明确的填空答案');
        return Number(q.isAutojudge)===1?value:toHTML(value);
      }).join('@@@');
    }
    if (kind !== 'single' && kind !== 'multiple') throw new Error('该题型暂不自动写入');
    const display = detail.options || [];
    const source = fromAI ? display : (q.options || []);
    if (!source.length || !display.length) throw new Error('选项数据不完整');
    const tokens = splitAnswer(raw, source);
    if (kind === 'single' && tokens.length !== 1) throw new Error('单选题必须恰好一个答案');
    if (!tokens.length || new Set(tokens).size !== tokens.length) throw new Error('答案选项为空或重复');
    const mapped = tokens.map(token => {
      const original = source.filter(o => optionId(o) === token);
      if (original.length !== 1) throw new Error('参考答案没有唯一对应选项：' + token);
      const text = plain(original[0].optionContent);
      if (!text) throw new Error('选项内容为空，无法可靠对应');
      const matches = display.filter(o => plain(o.optionContent) === text);
      if (matches.length !== 1 || !optionId(matches[0])) throw new Error('选项内容存在缺失或歧义，已跳过');
      return optionId(matches[0]);
    });
    if (kind === 'single') return mapped[0];
    if (!mapped.every(x => /^[A-Za-z0-9]$/.test(x))) throw new Error('多选题选项编码未知，不猜测写入格式');
    return mapped.sort().join('');
  }
  function equivalent(a, b, q) {
    if (!filled(a) || !filled(b)) return false;
    if (type(q) === 'judge') {
      try { return judgement(a) === judgement(b); } catch (_) { return false; }
    }
    if (type(q) === 'multiple') return String(a).replace(/[,，、;\s]/g, '').split('').sort().join('') === String(b).replace(/[,，、;\s]/g, '').split('').sort().join('');
    if(type(q)==='text')return usable(a,q)&&usable(b,q)&&textLines(a)===textLines(b);
    if(type(q)==='blank'){
      if(!usable(a,q)||!usable(b,q))return false;
      return String(a).split('@@@').every((part,i)=>textLines(part)===textLines(String(b).split('@@@')[i]));
    }
    return String(a).trim() === String(b).trim();
  }
  class Engine {
    constructor(report) {
      this.ctx = null;
      this.running = false;
      this.controller = null;
      this.report = report || (() => {});
    }
    stop() { if (this.controller) this.controller.abort(); }
    ensurePage(pid) {
      if(this.ctx?.deadlineAt!=null&&Date.now()>this.ctx.deadlineAt)throw new Error('作业已过截止时间，已停止处理');
      const current = parse(location.href);
      if (!current || current.pid !== pid) throw new Error('当前不是对应作业页，请先打开正确网址');
    }
    async request(path, options = {}) {
      if(['PUT','POST','PATCH'].includes(options.method)&&this.ctx?.deadlineAt!=null&&Date.now()>this.ctx.deadlineAt)throw new Error('作业已过截止时间，已停止写入');
      const url = new URL(path, location.origin);
      if (!origins.has(location.origin) || url.origin !== location.origin || !url.pathname.startsWith('/api/course/')) throw new Error('接口地址不在当前 U+ 站点内');
      const timeout = new AbortController();
      const timer = setTimeout(() => timeout.abort(), 15000);
      const external = this.controller && this.controller.signal;
      const stop = () => timeout.abort();
      if (external) {
        if (external.aborted) timeout.abort();
        external.addEventListener('abort', stop, {once: true});
      }
      try {
        if(globalThis.UPlusAPI){
          if(!this.apiAuth||this.apiAuth.stopped)this.apiAuth=new UPlusAPI.Client(location.origin);
          await this.apiAuth.auth();
        }
        const response = await fetch(url.href, {...options, credentials: 'same-origin',
          headers: {accept: 'application/json', ...(options.body ? {'content-type': 'application/json'} : {}), ...(this.apiAuth?.token?{'X-Access-Token':this.apiAuth.token}:{}), ...(options.headers || {})}, signal: timeout.signal});
        if (!response.ok) throw new Error('HTTP ' + response.status + (response.status === 401 || response.status === 403 ? '，请检查登录和权限' : ''));
        if (response.status === 204) return null;
        const json = await response.json();
        if (json.success !== true) throw new Error(json.message || '服务器未确认成功');
        return json.data;
      } finally {
        clearTimeout(timer);
        if (external) external.removeEventListener('abort', stop);
      }
    }
    emit() {
      const ctx = this.ctx;
      if (!ctx) return;
      this.report(this.summary());
    }
    summary() {
      if (!this.ctx) return null;
      return {schemaVersion:205,pid: this.ctx.pid, name: this.ctx.name, url: this.ctx.url,deadlineAt:this.ctx.deadlineAt,
        rows: this.ctx.rows.map(r => ({number:r.number,id:r.id,type:type(r.q),blankCount:type(r.q)==='blank'?Number(r.q.tiankongCount)||null:null,title:plain(r.q.titleText),status:r.status,answer:r.expected || '',displayAnswer:type(r.q)==='blank'?String(r.expected||'').split('@@@').map((p,i)=>'第'+(i+1)+'空：'+textLines(p)).join('\n'):type(r.q)==='text'?textLines(r.expected||''):r.expected||'',source:r.source || '',reason:r.reason || '',verified:!!r.verified,ai:!!r.ai,reviewed:!r.ai || !!r.reviewed,attachmentId:r.attachmentId||null,attachmentName:r.attachmentName||null})),
        canSubmit: !this.ctx.submitted && this.ctx.rows.length > 0 && this.ctx.rows.every(r => r.verified && (!r.ai || r.reviewed)),
        submitted: !!this.ctx.submitted};
    }
    async load(value,options={}) {
      if (this.running || this.submitting) throw new Error('已有操作进行中');
      const parsed = parse(value || location.href);
      if (!parsed) throw new Error('请输入完整 U+ 作业网址或准确的32位发布ID');
      this.running = true; this.controller = new AbortController();
      try {
        const pub = await this.request('/api/course/homeworks/published/' + parsed.pid + '/student');
        if (!pub || !/^[a-f0-9]{32}$/i.test(pub.homeworkId || '')) throw new Error('作业信息格式不正确');
        const [all, student] = await Promise.all([
          this.request('/api/course/homeworkQuestions?homeworkId=' + pub.homeworkId),
          this.request('/api/course/homeworkQuestions/student?homeworkId=' + pub.homeworkId)
        ]);
        if (!Array.isArray(all) || !Array.isArray(student) || !student.length) throw new Error('没有取得有效题目列表');
        const byId = new Map(all.map(q => [String(q.id),q]));
        const seen = new Set();
        const rows = student.map((s,i) => {
          const id = String(s.id || s.homeworkQuestionId || '');
          if (!/^[a-f0-9]{32}$/i.test(id) || seen.has(id)) throw new Error('学生题目编号缺失或重复');
          seen.add(id);
          const q = byId.get(id);
          if (!q) throw new Error('题目列表与学生题目不一致');
          return {id,number:s.orderNumber == null ? i+1 : s.orderNumber,q,student:s,status:'待处理',verified:false};
        });
        const deadlines=[options.deadlineAt,globalThis.UPlusSchedule?.fromURL(parsed.url).deadlineAt].filter(x=>Number.isFinite(x));
        const deadlineAt=deadlines.length?Math.min(...deadlines):null;
        this.ctx = {pid:parsed.pid,hid:pub.homeworkId,name:(pub.homeworkDTO && pub.homeworkDTO.name) || '作业',rows,url:parsed.url || location.href,deadlineAt};
        this.emit(); return this.summary();
      } finally { this.running = false; }
    }
    async detail(row) { return await this.request('/api/course/homeworkQuestions/' + row.id + '/student/detail'); }
    async run(options = {}) {
      if (this.running || this.submitting) throw new Error('已有操作进行中');
      if (!this.ctx) await this.load(location.href);
      this.ensurePage(this.ctx.pid);
      this.running = true; this.controller = new AbortController();
      try {
        for (const row of this.ctx.rows) {
          if (this.controller.signal.aborted) throw new Error('已停止');
          this.ensurePage(this.ctx.pid);
          row.status = '读取中'; row.reason = ''; this.emit();
          try {
            const detail = await this.detail(row);
            row.q=enrich(row.q,detail);
            const kind=type(row.q);
            if(kind==='attachment'){
              row.ai=false;row.reviewed=false;row.verified=false;row.expected='';
              row.attachmentId=null;row.attachmentName=null;
              row.status='未做（附件题）';row.source='按设置跳过';row.reason='附件题不自动处理，不生成文件、不上传、不以占位文本代替作答。请在 U+ 手动处理；本助手不计完成，也不正式提交这份作业。';
              this.emit();continue;
            }
            if(kind==='unsupported')throw new Error('该题型暂不自动写入，请在 U+ 网页手动处理');
            const stored = saved(detail);
            const existing = stored.known ? stored : saved(row.student);
            if (options.keepExisting !== false && existing.known && usable(existing.value,row.q)) {
              const priorAI = row.ai && equivalent(existing.value,row.expected,row.q);
              if (!priorAI) { row.ai=false;row.reviewed=false;row.source='原有答案'; }
              row.status = priorAI && !row.reviewed ? '保留AI答案，待复核' : '保留原答案';
              row.expected = String(existing.value); row.verified = true; this.emit(); continue;
            }
            let raw = row.q.answer;
            row.ai = false; row.reviewed = false;
            if (!filled(raw)||(['text','blank'].includes(kind)&&!usable(raw,row.q))) {
              if (!options.ai) throw new Error('平台没有参考答案；需配置 AI 或手动处理');
              row.status = 'AI 分析中'; this.emit();
              const result = await options.ai({type:kind,title:plain(row.q.titleText),...(kind==='blank'?{blankCount:blankCount(row.q)}:{}),options:(detail.options || []).map(o=>({id:optionId(o),text:plain(o.optionContent)}))});
              raw = result.answer; row.reason = result.reason || ''; row.ai = true;
              if(!filled(raw))throw new Error(result.reason || 'AI 未能确定答案');
            }
            row.expected = translate(row.q, detail, raw, row.ai);
            row.source = row.ai ? 'AI 建议，待复核' : '平台参考答案';
            row.status = '准备保存'; this.emit();
            if (options.dryRun) { row.status = '仅预览'; row.verified = false; this.emit(); continue; }
            await this.request('/api/course/hwAnswers/answer', {method:'PUT',body:JSON.stringify({homeworkQuestionId:row.id,userAnswer:row.expected})});
            let after = saved(await this.detail(row));
            if (!after.known) {
              const refreshed = await this.request('/api/course/homeworkQuestions/student?homeworkId=' + this.ctx.hid);
              const mine = Array.isArray(refreshed) && refreshed.find(q=>String(q.id || q.homeworkQuestionId)===row.id);
              after = saved(mine);
            }
            if (!after.known) throw new Error('服务器已响应，但无法回读学生答案，请在网页核对');
            if (!equivalent(after.value,row.expected,row.q)) throw new Error('回读答案与拟填答案不一致');
            row.verified = true;
            row.status = row.ai ? 'AI答案已保存，待复核' : '已保存并核对';
          } catch (error) {
            row.verified = false;
            row.status = this.controller.signal.aborted ? '已停止' : '待处理';
            row.reason = error.message || String(error);
            if (this.controller.signal.aborted) throw new Error('已停止');
          }
          this.emit();
          await new Promise(resolve=>setTimeout(resolve,120));
        }
        return this.summary();
      } finally { this.running = false; this.emit(); }
    }
    async verifyAll() {
      if (!this.ctx || this.running) throw new Error('请先完成填写');
      this.ensurePage(this.ctx.pid);
      this.controller = new AbortController();
      for (const row of this.ctx.rows) {
        const detail=await this.detail(row);row.q=enrich(row.q,detail);
        if(type(row.q)==='attachment'){
          row.verified=false;row.status='未做（附件题）';this.emit();throw new Error('第'+row.number+'题为附件题，按设置保持未做，不自动正式提交');
        }
        const actual = saved(detail);
        if (!actual.known || !equivalent(actual.value,row.expected,row.q)) { row.verified=false;row.status='提交前核对未通过';this.emit();throw new Error('第'+row.number+'题需要重新核对'); }
      }
      return this.summary();
    }
    reviewAI() { if (this.ctx) this.ctx.rows.filter(r=>r.ai).forEach(r=>{r.reviewed=true}); this.emit(); return this.summary(); }
    restore(summary) {
      if (!this.ctx || this.ctx.pid !== summary.pid) throw new Error('复核记录与作业不一致');
      if(this.ctx.rows.length!==summary.rows.length)throw new Error('题目数量已变化，请重新处理');
      this.ctx.submitted=!!summary.submitted;
      for (const row of this.ctx.rows) {
        const record = summary.rows.find(x=>x.id===row.id);
        if (!record) throw new Error('题目结构已变化，请重新处理');
        row.expected=record.answer;row.ai=record.ai;row.reviewed=record.reviewed;row.verified=record.verified;
        row.attachmentId=record.attachmentId||null;row.attachmentName=record.attachmentName||null;
        if(type(row.q)==='blank'&&Number.isInteger(record.blankCount)&&record.blankCount>0)row.q.tiankongCount=record.blankCount;
        if(type(row.q)==='attachment')row.verified=false;
        if(['text','blank'].includes(type(row.q))&&!usable(row.expected,row.q))row.verified=false;
        row.status=record.status;row.source=record.source;row.reason=record.reason;
      }
      return this.summary();
    }
    async submit() {
      if (this.running || this.submitting) throw new Error('已有操作进行中');
      if (this.ctx && this.ctx.submitted) throw new Error('此作业已经提交');
      if (!this.summary() || !this.summary().canSubmit) throw new Error('仍有待处理题目或未复核的 AI 答案');
      this.submitting=true;
      try {
        await this.verifyAll();
        this.running = true;
        await this.request('/api/course/hwAnswerSheets?homeworkPublishId=' + this.ctx.pid, {method:'POST'});
        this.ctx.submitted=true; this.emit(); return this.summary();
      } finally { this.running=false;this.submitting=false; }
    }
  }
  function mount(engine) {
    const old = document.getElementById('uplus-helper-v2');
    if (old) { old.hidden = false; return old; }
    const host = document.createElement('div');host.id='uplus-helper-v2';
    const shadow=host.attachShadow({mode:'open'});
    const style=document.createElement('style');style.textContent=':host{all:initial;position:fixed;right:14px;top:68px;z-index:2147483646;font:13px/1.6 system-ui;color:#263544}*{box-sizing:border-box}.panel{width:405px;max-height:82vh;background:#fff;border:1px solid #d5dfeb;border-radius:9px;box-shadow:0 8px 32px #0003;overflow:auto;padding:14px}h3{margin:0 0 8px;color:#276295}input[type=text]{width:100%;padding:8px;border:1px solid #bdccda;border-radius:4px}button{padding:7px 10px;margin:7px 6px 4px 0;background:#286f9a;color:#fff;border:0;border-radius:4px;cursor:pointer}button:disabled{opacity:.45;cursor:default}.danger{background:#a34d31}.muted{color:#748496;font-size:12px}.row{border-top:1px solid #e6ebf1;margin-top:9px;padding-top:8px;white-space:pre-wrap}.answer{color:#2b7252;font-weight:bold}.bad{color:#b13e3e}label{display:block;margin:6px 0}.top{display:flex;justify-content:space-between}.top button{margin:0;background:#68798a;padding:2px 9px}.status{white-space:pre-wrap}';
    shadow.appendChild(style);
    const panel=document.createElement('div');panel.className='panel';shadow.appendChild(panel);
    function el(tag,text,parent=panel){const n=document.createElement(tag);if(text)n.textContent=text;parent.appendChild(n);return n;}
    const top=el('div','');top.className='top';el('h3','U+ 自动填写与复核',top);const close=el('button','收起',top);close.onclick=()=>{host.hidden=true};
    const input=el('input');input.type='text';input.placeholder='作业网址或发布ID';input.value=location.href;
    const keep=el('label');const checkbox=el('input','',keep);checkbox.type='checkbox';checkbox.checked=true;keep.appendChild(document.createTextNode(' 保留已有答案'));
    const status=el('p','就绪');status.className='status muted';
    const out=el('div');
    const actions=el('div');
    function button(text,fn){const b=el('button',text,actions);b.onclick=async()=>{b.disabled=true;try{await fn()}catch(e){status.textContent=e.message}finally{b.disabled=false}};return b}
    button('获取/预览',()=>engine.load(input.value));
    button('自动填写并保存',async()=>{await engine.load(input.value);await engine.run({keepExisting:checkbox.checked})});
    button('停止',()=>engine.stop());
    button('已复核 AI 答案',()=>engine.reviewAI());
    const submit=button('确认提交此作业',async()=>{if(confirm('提交当前作业？提交前会再次核对所有答案。'))await engine.submit()});submit.className='danger';submit.disabled=true;
    button('导出结果',()=>{const blob=new Blob([JSON.stringify(engine.summary(),null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='U+填写复核结果.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)});
    el('p','自动保存草稿；提交始终需要确认。扩展管理页可扫描课程并安排批量处理。').className='muted';
    const prior=engine.report;
    engine.report=summary=>{
      prior(summary);out.replaceChildren();
      status.textContent=summary.name+'：'+summary.rows.filter(r=>r.verified).length+'/'+summary.rows.length+' 题已核对'+(summary.submitted?'；提交成功':'');
      submit.disabled=!summary.canSubmit||summary.submitted;
      summary.rows.forEach(row=>{
        const card=el('div','',out);card.className='row';
        el('strong','第 '+row.number+' 题 · '+row.status,card);
        el('div',row.title,card);
        if(row.answer)el('div','拟填/已存：'+(row.displayAnswer||row.answer),card).className='answer';
        if(row.reason)el('div',row.reason,card).className=row.verified?'muted':'bad';
      });
    };
    document.documentElement.appendChild(host);return host;
  }
  globalThis.UPlusEngine={version:'2.0.5',Engine,parse,plain,translate,equivalent,type,saved,mount,textLines,placeholder,blankCount,attachmentInfo,usable};
})();
