(function(){
 'use strict';
 if(globalThis.UPlusSchedule)return;
 function dateValue(text){
  const match=String(text||'').match(/(20\d{2})\s*[-/.年]\s*(\d{1,2})\s*[-/.月]\s*(\d{1,2})\s*日?(?:\s+|T)?(\d{1,2})\s*[:：]\s*(\d{2})(?:\s*[:：]\s*(\d{2}))?/);
  if(!match)return null;
  const [,year,month,day,hour,minute,second]=match;
  const parts=[+year,+month,+day,+hour,+minute,second==null?59:+second];
  const timestamp=Date.UTC(parts[0],parts[1]-1,parts[2],parts[3]-8,parts[4],parts[5]);
  const check=new Date(timestamp+8*3600000);
  if(check.getUTCFullYear()!==parts[0]||check.getUTCMonth()+1!==parts[1]||check.getUTCDate()!==parts[2]||parts[3]>23||parts[4]>59||parts[5]>59)return null;
  return timestamp;
 }
 function fromText(text,now=Date.now()){
  const value=String(text||'');
  const section=value.match(/(?:提交截止时间|截止时间|截止日期|提交截止|截止)\s*[:：]?\s*([^\n]{0,100})/);
  if(!section)return {known:false,expired:false,deadlineAt:null};
  const deadlineAt=dateValue(section[1]);
  if(deadlineAt!=null)return {known:true,expired:now>deadlineAt,deadlineAt};
  if(/^(?:不限|无限制|无截止时间|长期有效|永久有效|无期限)/.test(section[1]))return {known:true,expired:false,deadlineAt:null};
  return {known:false,expired:false,deadlineAt:null};
 }
 function fromURL(value,now=Date.now()){
  try{
   const raw=new URL(value).searchParams.get('endTime');
   if(!raw||!/^\d{10,13}$/.test(raw))return {known:false,expired:false,deadlineAt:null};
   const deadlineAt=Number(raw)*(raw.length===10?1000:1);
   if(deadlineAt<=0||!Number.isFinite(deadlineAt))return {known:false,expired:false,deadlineAt:null};
   return {known:true,expired:now>deadlineAt,deadlineAt};
  }catch(_){return {known:false,expired:false,deadlineAt:null}}
 }
 function job(item,now=Date.now()){
  const info=fromText(item.text,now),url=fromURL(item.url,now);
  const known=[info,url];
  if(item.deadlineKnown)known.push({known:true,deadlineAt:item.deadlineAt});
  const times=known.filter(x=>x.known&&Number.isFinite(x.deadlineAt)).map(x=>x.deadlineAt);
  if(times.length){const deadlineAt=Math.min(...times);return {known:true,expired:now>deadlineAt,deadlineAt}}
  return {known:known.some(x=>x.known),expired:false,deadlineAt:null};
 }
 globalThis.UPlusSchedule={dateValue,fromText,fromURL,job};
})();
