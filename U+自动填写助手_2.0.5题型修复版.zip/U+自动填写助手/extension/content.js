(function () {
  'use strict';
  if(globalThis.__uplusContent205)return;
  let engine, jobRunning=false,apiClient;
  function client(){if(!apiClient||apiClient.stopped)apiClient=new UPlusAPI.Client(location.origin);return apiClient}
  const send=message=>chrome.runtime.sendMessage(message).catch(()=>null);
  function getEngine() {
    if (!engine) {
      engine=new UPlusEngine.Engine(summary=>send({type:'PROGRESS',summary}));
      UPlusEngine.mount(engine);
    }
    return engine;
  }
  async function run(job) {
    if(jobRunning)return;
    jobRunning=true;
    try {
      const e=getEngine();
      await e.load(job.url,{deadlineAt:job.deadlineAt});
      if(job.summary)e.restore(job.summary);
      const result=await e.run({keepExisting:job.keepExisting,ai:job.useAI?question=>chrome.runtime.sendMessage({type:'AI',question}).then(result=>{if(result.error)throw new Error(result.error);return result}):null});
      await send({type:'DONE',summary:result});
    }catch(error){await send({type:'FAILED',error:'填写阶段：'+error.message})}
    finally{jobRunning=false;}
  }
  chrome.runtime.onMessage.addListener((message,sender,reply)=>{
    const perform=async()=>{
      if(message.type==='PING')return {ready:true};
      if(message.type==='API_COURSES')return {origin:location.origin,courses:await client().listCourses()};
      if(message.type==='API_HOMEWORKS')return await client().listHomeworks(message.courseId);
      if(message.type==='STOP_SCAN'){apiClient?.stop();return {stopped:true}}
      if(message.type==='COURSES'){
        if(location.pathname!=='/workbench/index/school')throw new Error('未进入学校课程工作台，请先登录');
        const cards=Array.from(document.querySelectorAll('.course-title-bottom'));
        const next=document.querySelector('.el-pagination .btn-next');
        return {courses:cards.map((e,index)=>({title:e.textContent.trim().replace(/\s+/g,' '),index})),hasNext:!!next&&!next.disabled&&!next.classList.contains('is-disabled')};
      }
      if(message.type==='COURSES_SCROLL'){
        const card=document.querySelector('.course-title-bottom');
        let parent=card&&card.parentElement;
        while(parent&&parent!==document.body){if(parent.scrollHeight>parent.clientHeight+5&&/auto|scroll/.test(getComputedStyle(parent).overflowY)){parent.scrollTop=parent.scrollHeight;break}parent=parent.parentElement}
        window.scrollTo(0,document.documentElement.scrollHeight);
        return {scrolled:true};
      }
      if(message.type==='COURSES_NEXT'){
        const next=document.querySelector('.el-pagination .btn-next');
        if(!next||next.disabled||next.classList.contains('is-disabled'))return {changed:false};
        next.click();return {changed:true};
      }
      if(message.type==='SCAN') {
        if(!/^\/course\/course\/[a-f0-9]{32}\/HomeworkPage/i.test(location.pathname))throw new Error('不是课程作业列表页');
        let expired=0,unknown=0;
        const cards=Array.from(document.querySelectorAll('.list-container')).map((card,index)=>{
          const title=card.querySelector('.homework-title');
          const button=Array.from(card.querySelectorAll('button')).find(b=>/^(去做作业|继续作业)$/.test(b.textContent.trim())&&!b.disabled);
          if(!title||!button)return null;
          const text=card.innerText,deadline=UPlusSchedule.fromText(text);
          if(deadline.expired){expired++;return null}
          if(!deadline.known){unknown++;return null}
          return {title:title.textContent.trim().replace(/\s+/g,' '),index,listURL:location.href,text:text.slice(0,1500),deadlineKnown:true,deadlineAt:deadline.deadlineAt};
        }).filter(Boolean);
        return {cards,expired,unknown};
      }
      if(message.type==='LIST_STATE'){
        if(!/^\/course\/course\/[a-f0-9]{32}\/HomeworkPage/i.test(location.pathname))throw new Error('未进入课程作业列表，请检查登录状态');
        const next=document.querySelector('.el-pagination .btn-next');
        const cards=Array.from(document.querySelectorAll('.list-container'));
        const list=document.querySelector('.homework-list')||cards[0]?.parentElement;
        const body=document.body.innerText;
        const login=!!document.querySelector('input[type="password"]')&&!list&&/登录|login/i.test(body);
        const completeCards=cards.length>0&&cards.every(card=>card.querySelector('.homework-title')?.textContent.trim());
        const loading=!completeCards&&Array.from(document.querySelectorAll('.el-loading-mask')).some(e=>{
          const style=getComputedStyle(e);
          return e.getClientRects().length>0&&style.display!=='none'&&style.visibility!=='hidden'&&Number(style.opacity)>0&&!!list&&(list.contains(e)||e.parentElement.contains(list));
        });
        const empty=!!document.querySelector('.el-empty')||/暂无作业|尚未发布作业|没有发布的作业|还没有作业/.test(body);
        return {ready:!!list||cards.length>0||empty,loading,login,signature:cards.map(e=>e.querySelector('.homework-title')?.textContent.trim()).join('|'),hasNext:!!next&&!next.disabled&&!next.classList.contains('is-disabled'),hint:loading?'作业区域仍在加载':list?'作业区域已出现':login?'需要重新登录':document.title+'，未出现作业区域'};
      }
      if(message.type==='LIST_NEXT'){
        const next=document.querySelector('.el-pagination .btn-next');
        if(!next||next.disabled||next.classList.contains('is-disabled'))return {changed:false};
        next.click();return {changed:true};
      }
      if(message.type==='RUN'){run(message.job);return {accepted:true}}
      if(message.type==='STOP'){if(engine)engine.stop();return {stopped:true}}
      if(message.type==='SHOW'){getEngine();return {shown:true}}
      if(message.type==='SUBMIT') {
        if(jobRunning)throw new Error('填写仍在进行中');
        const e=getEngine();
        await e.load(message.summary.url,{deadlineAt:message.summary.deadlineAt});e.restore(message.summary);
        if(message.reviewAI)e.reviewAI();
        return await e.submit();
      }
      throw new Error('未知消息');
    };
    perform().then(result=>reply({result})).catch(error=>reply({error:error.message}));return true;
  });
  globalThis.__uplusContent205=true;
})();
